#include <iostream>
#include <fstream> // Required for file operations
#include <string>

int main() {
    std::string filename = "test.txt";
    std::string data;

    // --- Writing to a file (overwrites existing content) ---
    std::ofstream outFile(filename); // Opens file in write mode (truncates)
    if (outFile.is_open()) {
        outFile << "Hello from C++!\n";
        outFile << "This is some new data.\n";
        outFile.close();
        std::cout << "Successfully wrote to " << filename << std::endl;
    } else {
        std::cerr << "Error opening file for writing!" << std::endl;
    }

    // --- Reading from a file ---
    std::ifstream inFile(filename); // Opens file in read mode
    if (inFile.is_open()) {
        std::cout << "\n--- Reading from " << filename << " ---" << std::endl;
        while (getline(inFile, data)) { // Reads line by line
            std::cout << data << std::endl;
        }
        inFile.close();
    } else {
        std::cerr << "Error opening file for reading!" << std::endl;
    }

    // --- Appending to a file ---
    // std::ios::app ensures data is added to the end
    std::ofstream appendFile(filename, std::ios::app);
    if (appendFile.is_open()) {
        appendFile << "Appending this line.\n";
        appendFile << "Another appended line.\n";
        appendFile.close();
        std::cout << "\nSuccessfully appended to " << filename << std::endl;
    } else {
        std::cerr << "Error opening file for appending!" << std::endl;
    }

    // --- Verify appended content by reading again ---
    std::cout << "\n--- Reading after appending ---" << std::endl;
    std::ifstream verifyFile(filename);
    if (verifyFile.is_open()) {
        while (getline(verifyFile, data)) {
            std::cout << data << std::endl;
        }
        verifyFile.close();
    } else {
        std::cerr << "Error opening file for verification!" << std::endl;
    }

    return 0;
}